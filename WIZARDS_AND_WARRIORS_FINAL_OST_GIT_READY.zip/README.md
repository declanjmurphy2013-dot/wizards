# Wizards & Warriors — The Lantern Oath · Full Soundtrack Edition

This edition embeds the four WAV recordings supplied by the game's author, so **no music downloads, import menu, network, install or server are needed to play**. The actual song recordings are encoded as high-quality 192 kb/s MP3 inside the single-file game, with original WAV masters included separately in `soundtrack/`.

## Play

Extract the archive. Open **index.html** in Chrome or Edge. Click/tap or press a key once to unlock audio. Select CPU or Story. On mobile, use a browser that supports playing local HTML files, or publish the site on static hosting. Only touch devices see touch controls.

## Music

- Menu and story: Main Theme (`6493953972633600.wav`)
- Fight: Battle Theme (`6637979929542656.wav`)
- Below 30% **local-player** health during a fight: Low-Health Theme (`4918884909580288.wav`)
- Winning: Victory Theme (`4745320851963904.wav`)
- Losing: existing short defeat jingle (no new defeat recording supplied)

Music cross-fades when entering/leaving battles and low-health state. It ends or resets appropriately on victory, defeat, and return to the menu. Music respects the sound toggle and volume setting. Save key, progression, roster and controls have not changed.

The two short plucked recordings are closely related arrangements; their exact song-page IDs cannot be confirmed from local WAV metadata, so role assignment follows their upload order and song naming. `SOUNDTRACK_MANIFEST.json` includes SHA-256 checksums and the supplied links.

## Git

`index.html` is a self-contained, offline playable version. To update the original repo, copy this `index.html` over the repo's existing `index.html`, then run `git add index.html && git commit -m "Integrate original four-track soundtrack" && git push origin main` from your own authenticated local clone. This build is **not yet published to GitHub** because the connected GitHub integration denies writes (HTTP 403). No repository files were overwritten remotely. Before replacing an actively edited `index.html`, first back it up / commit it.
